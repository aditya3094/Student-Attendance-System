Student Attendance System

This is a simple Student Attendance Management System built in Java.  
It helps faculty to mark, view, and manage attendance easily.

 ✨ Features
- Add and manage student records
- Mark daily attendance
- View attendance reports
- Simple and clean interface

📌 Technologies Used
- Java
- ( Swing / JavaFX )

🛠 Installation & Running
1. Clone the repository:
   ```bash
   git clone https://github.com/aditya3094/Student-Attendance-System.git
